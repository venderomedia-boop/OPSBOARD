import type { DashboardFilters, Feedback, Invoice, Job, KpiMetric, OpsData, ScenarioId } from '../types';

const money = new Intl.NumberFormat('en-GB', { style: 'currency', currency: 'GBP', maximumFractionDigits: 0 });
const shortMoney = new Intl.NumberFormat('en-GB', { style: 'currency', currency: 'GBP', notation: 'compact', maximumFractionDigits: 1 });

export function getRangeStart(range: DashboardFilters['dateRange']): Date {
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  if (range === 'week') start.setDate(start.getDate() - 6);
  if (range === 'month') start.setDate(start.getDate() - 29);
  return start;
}

export function inSelectedRange(iso: string | undefined, range: DashboardFilters['dateRange']): boolean {
  if (!iso) return false;
  const start = getRangeStart(range).getTime();
  const end = Date.now() + 86400000;
  const value = new Date(iso).getTime();
  return value >= start && value < end;
}

export function filterJobs(data: OpsData, filters: DashboardFilters): Job[] {
  return data.jobs.filter((job) => {
    if (!inSelectedRange(job.scheduledStart, filters.dateRange)) return false;
    if (filters.technicianId !== 'all' && job.technicianId !== filters.technicianId) return false;
    if (filters.clientId !== 'all' && job.clientId !== filters.clientId) return false;
    if (filters.serviceTypeId !== 'all' && job.serviceTypeId !== filters.serviceTypeId) return false;
    return true;
  });
}

export function relatedInvoices(data: OpsData, jobs: Job[]): Invoice[] {
  const ids = new Set(jobs.map((job) => job.id));
  return data.invoices.filter((invoice) => ids.has(invoice.jobId));
}

export function relatedFeedback(data: OpsData, jobs: Job[]): Feedback[] {
  const ids = new Set(jobs.map((job) => job.id));
  return data.feedback.filter((feedback) => ids.has(feedback.jobId));
}

export function calcMetrics(data: OpsData, filters: DashboardFilters, scenario: ScenarioId): KpiMetric[] {
  const jobs = filterJobs(data, filters);
  const invoices = relatedInvoices(data, jobs);
  const feedback = relatedFeedback(data, jobs);
  const scheduled = jobs.filter((job) => job.status !== 'cancelled').length;
  const completed = jobs.filter((job) => job.status === 'completed').length;
  const atRisk = jobs.filter((job) => job.status === 'overdue' || job.issueFlag === 'unassigned' || job.issueFlag === 'callback').length;
  const pending = invoices.filter((invoice) => invoice.status === 'not_created' || invoice.status === 'draft').reduce((sum, invoice) => sum + invoice.amount, 0);
  const outstanding = invoices.filter((invoice) => invoice.status === 'sent' || invoice.status === 'overdue').reduce((sum, invoice) => sum + invoice.amount, 0);
  const invoiceDelays = invoices
    .filter((invoice) => invoice.createdAt)
    .map((invoice) => {
      const job = data.jobs.find((item) => item.id === invoice.jobId);
      if (!job?.completedAt) return 0;
      return (new Date(invoice.createdAt!).getTime() - new Date(job.completedAt).getTime()) / 86400000;
    })
    .filter((value) => value >= 0);
  const avgInvoiceDelay = invoiceDelays.length ? invoiceDelays.reduce((a, b) => a + b, 0) / invoiceDelays.length : 0;
  const csat = feedback.length ? feedback.reduce((sum, item) => sum + item.rating, 0) / feedback.length : 0;
  const totalAvailableHours = data.technicians.filter((tech) => filters.technicianId === 'all' || tech.id === filters.technicianId).reduce((sum, tech) => sum + tech.shiftHours, 0);
  const assignedHours = jobs.reduce((sum, job) => sum + Math.max(0, (new Date(job.scheduledEnd).getTime() - new Date(job.scheduledStart).getTime()) / 3600000), 0);
  let utilization = Math.min(100, totalAvailableHours ? (assignedHours / totalAvailableHours) * 100 : 0);
  const revenue = jobs.filter((job) => job.status === 'completed').reduce((sum, job) => sum + (job.finalAmount ?? job.quotedAmount), 0);

  if (scenario === 'staffing') utilization = Math.min(96, utilization + 15);
  if (scenario === 'growth') utilization = Math.min(94, utilization + 8);

  return [
    { key: 'completed', label: 'Jobs completed', value: `${completed} / ${scheduled}`, rawValue: completed, helper: 'Completed vs scheduled in selected period', delta: scenario === 'growth' ? '+18% vs prior period' : '+6% vs prior period', tone: completed / Math.max(1, scheduled) > 0.7 ? 'good' : 'neutral' },
    { key: 'risk', label: 'Jobs at risk', value: String(atRisk), rawValue: atRisk, helper: `${atRisk} exceptions need review`, delta: atRisk > 3 ? 'Immediate attention' : 'Within normal range', tone: atRisk > 4 ? 'danger' : atRisk > 1 ? 'warning' : 'good' },
    { key: 'pending', label: 'Invoices awaiting issue', value: money.format(pending), rawValue: pending, helper: 'Completed work not yet sent to customer', delta: pending > 5000 ? 'Cash trapped after completion' : 'Closeout queue', tone: pending > 6500 ? 'danger' : pending > 2500 ? 'warning' : 'good' },
    { key: 'invoice-time', label: 'Average time to invoice', value: `${avgInvoiceDelay.toFixed(1)} days`, rawValue: avgInvoiceDelay, helper: 'Completion to invoice creation', delta: avgInvoiceDelay > 2 ? 'Above 48h target' : 'Within 48h target', tone: avgInvoiceDelay > 2 ? 'warning' : 'good' },
    { key: 'outstanding', label: 'Outstanding invoices', value: money.format(outstanding), rawValue: outstanding, helper: 'Sent or overdue and unpaid', delta: invoices.filter((i) => i.status === 'overdue').length ? `${invoices.filter((i) => i.status === 'overdue').length} overdue` : 'No overdue balances', tone: invoices.some((i) => i.status === 'overdue') ? 'warning' : 'neutral' },
    { key: 'csat', label: 'Customer satisfaction', value: csat ? `${csat.toFixed(1)} / 5` : '—', rawValue: csat, helper: `${feedback.length} feedback responses`, delta: scenario === 'quality' ? '↓ service quality signal' : 'Stable', tone: csat && csat < 4.2 ? 'danger' : csat < 4.5 ? 'warning' : 'good' },
    { key: 'utilization', label: 'Schedule utilization', value: `${Math.round(utilization)}%`, rawValue: utilization, helper: 'Assigned job time vs available shifts', delta: utilization > 90 ? 'Capacity constrained' : 'Balanced capacity', tone: utilization > 92 ? 'danger' : utilization > 85 ? 'warning' : 'good' },
    { key: 'revenue', label: 'Revenue completed', value: money.format(revenue), rawValue: revenue, helper: 'Completed job value in selected period', delta: scenario === 'growth' ? '+22% vs prior period' : '+9% vs prior period', tone: 'neutral' },
  ];
}

export function buildDailySeries(data: OpsData, filters: DashboardFilters, days = 14) {
  const rows: { date: string; scheduled: number; completed: number; revenue: number; invoiceDelay: number; csat: number }[] = [];
  const now = new Date();
  for (let offset = days - 1; offset >= 0; offset -= 1) {
    const day = new Date(now.getFullYear(), now.getMonth(), now.getDate() - offset);
    const start = day.getTime();
    const end = start + 86400000;
    const jobs = data.jobs.filter((job) => {
      const t = new Date(job.scheduledStart).getTime();
      if (t < start || t >= end) return false;
      if (filters.technicianId !== 'all' && job.technicianId !== filters.technicianId) return false;
      if (filters.clientId !== 'all' && job.clientId !== filters.clientId) return false;
      if (filters.serviceTypeId !== 'all' && job.serviceTypeId !== filters.serviceTypeId) return false;
      return true;
    });
    const ids = new Set(jobs.map((job) => job.id));
    const invoices = data.invoices.filter((invoice) => ids.has(invoice.jobId));
    const feedback = data.feedback.filter((item) => ids.has(item.jobId));
    const delays = invoices.filter((i) => i.createdAt).map((i) => {
      const job = jobs.find((j) => j.id === i.jobId);
      return job?.completedAt ? (new Date(i.createdAt!).getTime() - new Date(job.completedAt).getTime()) / 86400000 : 0;
    });
    rows.push({
      date: day.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' }),
      scheduled: jobs.length,
      completed: jobs.filter((job) => job.status === 'completed').length,
      revenue: jobs.filter((job) => job.status === 'completed').reduce((sum, job) => sum + (job.finalAmount ?? job.quotedAmount), 0),
      invoiceDelay: delays.length ? delays.reduce((a, b) => a + b, 0) / delays.length : 0,
      csat: feedback.length ? feedback.reduce((sum, item) => sum + item.rating, 0) / feedback.length : 0,
    });
  }
  return rows;
}

export const formatMoney = (value: number) => money.format(value);
export const formatShortMoney = (value: number) => shortMoney.format(value);
