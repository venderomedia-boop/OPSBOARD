import { ArrowDownRight, ArrowUpRight, ChevronRight, CircleAlert, CircleCheck, Clock3, Info } from 'lucide-react';
import type { KpiMetric } from '../types';

const toneIcon = {
  good: CircleCheck,
  warning: Clock3,
  danger: CircleAlert,
  neutral: Info,
};

export default function KpiGrid({ metrics, onOpen }: { metrics: KpiMetric[]; onOpen: (metric: KpiMetric) => void }) {
  return (
    <div className="kpi-grid">
      {metrics.map((metric) => {
        const tone = metric.tone ?? 'neutral';
        const Icon = toneIcon[tone];
        const negative = metric.delta?.includes('↓') || metric.delta?.toLowerCase().includes('attention') || metric.delta?.toLowerCase().includes('above');
        return (
          <button className={`kpi-card tone-${tone}`} key={metric.key} onClick={() => onOpen(metric)}>
            <div className="kpi-head"><span>{metric.label}</span><Icon size={15} /></div>
            <div className="kpi-value">{metric.value}</div>
            <div className="kpi-bottom">
              <span className="kpi-delta">{negative ? <ArrowDownRight size={13} /> : <ArrowUpRight size={13} />}{metric.delta}</span>
              <ChevronRight className="kpi-chevron" size={14} />
            </div>
          </button>
        );
      })}
    </div>
  );
}
