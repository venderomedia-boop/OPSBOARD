import { useMemo, useState } from 'react';
import { CheckCircle2, X } from 'lucide-react';
import Sidebar from './components/Sidebar';
import TopBar from './components/TopBar';
import DetailDrawer, { type DrawerTarget } from './components/DetailDrawer';
import DashboardView from './views/DashboardView';
import OperationalViews from './views/OperationalViews';
import { createSeedData } from './data/seed';
import { applyScenario, scenarioMeta } from './data/scenarios';
import { calcMetrics, filterJobs, relatedFeedback, relatedInvoices } from './data/metrics';
import type { DashboardFilters, InvoiceStatus, ScenarioId, ViewId } from './types';

export default function App() {
  const baseData = useMemo(() => createSeedData(), []);
  const [view, setView] = useState<ViewId>('dashboard');
  const [scenario, setScenario] = useState<ScenarioId>('normal');
  const [filters, setFilters] = useState<DashboardFilters>({ dateRange: 'today', technicianId: 'all', clientId: 'all', serviceTypeId: 'all' });
  const [theme, setTheme] = useState<'light' | 'dark'>(() => (localStorage.getItem('ops-hub-theme') as 'light' | 'dark') || 'dark');
  const [drawer, setDrawer] = useState<DrawerTarget>(null);
  const [invoiceOverrides, setInvoiceOverrides] = useState<Record<string, InvoiceStatus>>({});
  const [toast, setToast] = useState<string | null>(null);

  const scenarioData = useMemo(() => applyScenario(baseData, scenario), [baseData, scenario]);
  const data = useMemo(() => ({ ...scenarioData, invoices: scenarioData.invoices.map((invoice) => invoiceOverrides[invoice.id] ? { ...invoice, status: invoiceOverrides[invoice.id], sentAt: invoiceOverrides[invoice.id] === 'sent' ? new Date().toISOString() : invoice.sentAt } : invoice) }), [scenarioData, invoiceOverrides]);
  const metrics = useMemo(() => calcMetrics(data, filters, scenario), [data, filters, scenario]);

  const changeTheme = () => setTheme((current) => {
    const next = current === 'dark' ? 'light' : 'dark';
    localStorage.setItem('ops-hub-theme', next);
    return next;
  });

  const notify = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(null), 3000);
  };

  const sendInvoice = (id: string) => {
    setInvoiceOverrides((current) => ({ ...current, [id]: 'sent' }));
    notify(`${id} marked as sent in the demo. Dashboard metrics updated.`);
  };

  const simulate = (action: 'send-invoice' | 'reassign', id: string) => {
    if (action === 'send-invoice') {
      sendInvoice(id);
      return;
    }
    notify(`Work rebalanced around ${data.technicians.find((tech) => tech.id === id)?.name ?? 'the selected technician'} — simulated demo action.`);
  };

  const onScenario = (next: ScenarioId) => {
    setScenario(next);
    setInvoiceOverrides({});
    setDrawer(null);
    notify(`Scenario changed: ${scenarioMeta[next].label}.`);
  };

  const exportCurrent = () => {
    const jobs = filterJobs(data, filters);
    let rows: Record<string, string | number>[] = [];
    if (view === 'invoices') {
      rows = relatedInvoices(data, jobs).map((invoice) => ({ invoice: invoice.id, job: invoice.jobId, status: invoice.status, amount: invoice.amount, created: invoice.createdAt ?? '', sent: invoice.sentAt ?? '', due: invoice.dueAt ?? '' }));
    } else if (view === 'feedback') {
      rows = relatedFeedback(data, jobs).map((item) => ({ feedback: item.id, job: item.jobId, rating: item.rating, category: item.category ?? '', comment: item.comment ?? '', submitted: item.submittedAt }));
    } else {
      rows = jobs.map((job) => ({ job: job.id, client: data.clients.find((client) => client.id === job.clientId)?.name ?? '', technician: data.technicians.find((tech) => tech.id === job.technicianId)?.name ?? 'Unassigned', service: data.serviceTypes.find((service) => service.id === job.serviceTypeId)?.name ?? '', status: job.status, issue: job.issueFlag ?? '', scheduled: job.scheduledStart, value: job.finalAmount ?? job.quotedAmount }));
    }
    if (!rows.length) return notify('No rows match the current filters.');
    const headers = Object.keys(rows[0]);
    const escape = (value: string | number) => `"${String(value).replaceAll('"', '""')}"`;
    const csv = [headers.map(escape).join(','), ...rows.map((row) => headers.map((header) => escape(row[header])).join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `ops-hub-${view}-${new Date().toISOString().slice(0, 10)}.csv`;
    anchor.click();
    URL.revokeObjectURL(url);
    notify(`Exported ${rows.length} rows from the current view.`);
  };

  return (
    <div className={`app-shell theme-${theme}`}>
      <Sidebar view={view} onChange={setView} />
      <div className="workspace">
        <TopBar
          filters={filters}
          onFilters={setFilters}
          scenario={scenario}
          onScenario={onScenario}
          technicians={data.technicians}
          clients={data.clients}
          serviceTypes={data.serviceTypes}
          theme={theme}
          onTheme={changeTheme}
          onExport={exportCurrent}
        />
        <main className="content">
          {scenario !== 'normal' && (
            <div className="scenario-banner">
              <span className="scenario-dot" />
              <div><b>{scenarioMeta[scenario].label}</b><span>{scenarioMeta[scenario].description}</span></div>
              <button onClick={() => onScenario('normal')}>Return to normal</button>
            </div>
          )}
          {view === 'dashboard' ? (
            <DashboardView
              data={data}
              filters={filters}
              scenario={scenario}
              metrics={metrics}
              theme={theme}
              onMetric={(metric) => setDrawer({ type: 'kpi', metric })}
              onOpenJob={(id) => setDrawer({ type: 'job', id })}
              onOpenInvoice={(id) => setDrawer({ type: 'invoice', id })}
              onOpenFeedback={(id) => setDrawer({ type: 'feedback', id })}
              onSimulate={simulate}
            />
          ) : (
            <OperationalViews
              view={view}
              data={data}
              filters={filters}
              theme={theme}
              onOpenJob={(id) => setDrawer({ type: 'job', id })}
              onOpenInvoice={(id) => setDrawer({ type: 'invoice', id })}
              onOpenFeedback={(id) => setDrawer({ type: 'feedback', id })}
              onOpenTech={(id) => setDrawer({ type: 'technician', id })}
              onOpenClient={(id) => setDrawer({ type: 'client', id })}
            />
          )}
        </main>
      </div>
      <DetailDrawer target={drawer} data={data} onClose={() => setDrawer(null)} onSendInvoice={sendInvoice} onOpenJob={(id) => setDrawer({ type: 'job', id })} />
      {toast && <div className="toast"><CheckCircle2 size={17}/><span>{toast}</span><button onClick={() => setToast(null)}><X size={15}/></button></div>}
    </div>
  );
}
