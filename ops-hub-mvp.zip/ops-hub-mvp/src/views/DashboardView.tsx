import ReactECharts from 'echarts-for-react';
import { ArrowRight, CircleDollarSign, Clock3, MessageCircleWarning, MoreHorizontal, Route, Send, UserRoundCog } from 'lucide-react';
import type { DashboardFilters, KpiMetric, OpsData, ScenarioId } from '../types';
import { buildDailySeries, filterJobs, formatMoney, formatShortMoney, relatedFeedback, relatedInvoices } from '../data/metrics';
import KpiGrid from '../components/KpiGrid';
import Panel from '../components/Panel';
import StatusBadge from '../components/StatusBadge';

const fmtTime = (iso?: string) => iso ? new Date(iso).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }) : '—';

export default function DashboardView({
  data, filters, scenario, metrics, theme, onMetric, onOpenJob, onOpenInvoice, onOpenFeedback, onSimulate,
}: {
  data: OpsData;
  filters: DashboardFilters;
  scenario: ScenarioId;
  metrics: KpiMetric[];
  theme: 'light' | 'dark';
  onMetric: (metric: KpiMetric) => void;
  onOpenJob: (id: string) => void;
  onOpenInvoice: (id: string) => void;
  onOpenFeedback: (id: string) => void;
  onSimulate: (action: 'send-invoice' | 'reassign', id: string) => void;
}) {
  const jobs = filterJobs(data, filters);
  const invoices = relatedInvoices(data, jobs);
  const feedback = relatedFeedback(data, jobs);
  const pendingInvoices = invoices.filter((invoice) => invoice.status === 'not_created' || invoice.status === 'draft');
  const lowFeedback = feedback.filter((item) => item.rating <= 3).sort((a, b) => a.rating - b.rating);
  const atRisk = jobs.filter((job) => job.status === 'overdue' || job.issueFlag === 'unassigned' || job.issueFlag === 'callback');
  const timeline = jobs
    .filter((job) => ['today', 'week', 'month'].includes(filters.dateRange))
    .sort((a, b) => new Date(a.scheduledStart).getTime() - new Date(b.scheduledStart).getTime())
    .slice(0, filters.dateRange === 'today' ? 12 : 9);

  const completedValue = jobs.filter((job) => job.status === 'completed').reduce((sum, job) => sum + (job.finalAmount ?? job.quotedAmount), 0);
  const draftedValue = invoices.filter((invoice) => invoice.status !== 'not_created').reduce((sum, invoice) => sum + invoice.amount, 0);
  const sentValue = invoices.filter((invoice) => ['sent', 'overdue', 'paid'].includes(invoice.status)).reduce((sum, invoice) => sum + invoice.amount, 0);
  const paidValue = invoices.filter((invoice) => invoice.status === 'paid').reduce((sum, invoice) => sum + invoice.amount, 0);
  const funnel = [
    { label: 'Completed work', value: completedValue, helper: `${jobs.filter((job) => job.status === 'completed').length} jobs` },
    { label: 'Invoice created', value: draftedValue, helper: `${invoices.filter((invoice) => invoice.status !== 'not_created').length} invoices` },
    { label: 'Invoice sent', value: sentValue, helper: `${invoices.filter((invoice) => ['sent', 'overdue', 'paid'].includes(invoice.status)).length} sent` },
    { label: 'Cash collected', value: paidValue, helper: `${invoices.filter((invoice) => invoice.status === 'paid').length} paid` },
  ];
  const maxFunnel = Math.max(...funnel.map((item) => item.value), 1);
  const series = buildDailySeries(data, filters, 14);
  const chartText = theme === 'dark' ? '#a9b4c7' : '#697386';
  const grid = theme === 'dark' ? '#263244' : '#e9edf3';
  const primary = '#5b7cfa';
  const warning = '#f59e0b';

  const jobsOption = {
    animationDuration: 450,
    tooltip: { trigger: 'axis', backgroundColor: theme === 'dark' ? '#101827' : '#fff', borderColor: grid, textStyle: { color: theme === 'dark' ? '#f5f7fb' : '#111827' } },
    grid: { left: 6, right: 8, top: 20, bottom: 0, containLabel: true },
    xAxis: { type: 'category', data: series.map((row) => row.date), axisLine: { lineStyle: { color: grid } }, axisLabel: { color: chartText, fontSize: 10 }, axisTick: { show: false } },
    yAxis: { type: 'value', minInterval: 1, splitLine: { lineStyle: { color: grid, type: 'dashed' } }, axisLabel: { color: chartText, fontSize: 10 } },
    series: [
      { name: 'Scheduled', type: 'line', data: series.map((row) => row.scheduled), smooth: true, symbol: 'none', lineStyle: { width: 2, color: primary }, areaStyle: { opacity: 0.08, color: primary } },
      { name: 'Completed', type: 'line', data: series.map((row) => row.completed), smooth: true, symbol: 'none', lineStyle: { width: 2, color: warning } },
    ],
  };

  const invoiceOption = {
    animationDuration: 450,
    tooltip: { trigger: 'axis', formatter: (params: any) => `${params[0].axisValue}<br/>${params[0].marker} ${Number(params[0].value).toFixed(1)} days`, backgroundColor: theme === 'dark' ? '#101827' : '#fff', borderColor: grid, textStyle: { color: theme === 'dark' ? '#f5f7fb' : '#111827' } },
    grid: { left: 6, right: 8, top: 20, bottom: 0, containLabel: true },
    xAxis: { type: 'category', data: series.map((row) => row.date), axisLine: { lineStyle: { color: grid } }, axisLabel: { color: chartText, fontSize: 10 }, axisTick: { show: false } },
    yAxis: { type: 'value', splitLine: { lineStyle: { color: grid, type: 'dashed' } }, axisLabel: { color: chartText, formatter: '{value}d', fontSize: 10 } },
    series: [{ name: 'Invoice cycle', type: 'bar', barMaxWidth: 18, data: series.map((row) => Number(row.invoiceDelay.toFixed(1))), itemStyle: { color: primary, borderRadius: [4, 4, 0, 0] } }],
  };

  const firstPending = pendingInvoices[0];
  const firstLow = lowFeedback[0];
  const firstAtRisk = atRisk[0];
  const jordan = data.technicians.find((tech) => tech.name === 'Jordan Reed');

  return (
    <>
      <section className="page-intro dashboard-intro">
        <div>
          <div className="eyebrow">Executive overview</div>
          <h1>Today&apos;s operational control center</h1>
          <p>See cash bottlenecks, customer risk and capacity exceptions without opening each source system.</p>
        </div>
        <div className="source-strip"><span>Sources</span><b>Dispatch</b><b>Accounting</b><b>Customer Feedback</b></div>
      </section>

      <KpiGrid metrics={metrics} onOpen={onMetric} />

      <div className="dashboard-grid">
        <Panel eyebrow="Exceptions" title="Action center" description="Prioritized by operational consequence, not by system." className="action-panel">
          <div className="action-list">
            <ActionRow icon={<Clock3 size={17} />} tone="danger" title={`${atRisk.length} jobs need attention`} body={firstAtRisk ? `${firstAtRisk.id} · ${firstAtRisk.summary}` : 'No urgent job exceptions'} button="View job" disabled={!firstAtRisk} onClick={() => firstAtRisk && onOpenJob(firstAtRisk.id)} />
            <ActionRow icon={<CircleDollarSign size={17} />} tone="warning" title={`${pendingInvoices.length} completed jobs are not invoiced`} body={`${formatMoney(pendingInvoices.reduce((sum, item) => sum + item.amount, 0))} waiting between completion and invoice`} button="Send invoice" disabled={!firstPending} onClick={() => firstPending && onSimulate('send-invoice', firstPending.id)} />
            <ActionRow icon={<MessageCircleWarning size={17} />} tone="warning" title={`${lowFeedback.length} customers rated service 3★ or lower`} body={firstLow?.comment ?? 'No negative feedback in this period'} button="Review" disabled={!firstLow} onClick={() => firstLow && onOpenFeedback(firstLow.id)} />
            <ActionRow icon={<UserRoundCog size={17} />} tone="neutral" title="45-minute schedule gap detected" body={`${jordan?.name ?? 'Jordan Reed'} · 14:15–15:00 · HVAC skill match nearby`} button="Reassign work" onClick={() => onSimulate('reassign', jordan?.id ?? 't1')} />
          </div>
        </Panel>

        <Panel eyebrow="Today" title="Operations timeline" description="Exceptions stay visible beside the live schedule." action={<button className="text-button">Full schedule <ArrowRight size={14} /></button>} className="timeline-panel">
          <div className="timeline-list">
            {timeline.map((job) => {
              const client = data.clients.find((item) => item.id === job.clientId);
              const tech = data.technicians.find((item) => item.id === job.technicianId);
              return (
                <button className={`timeline-row ${job.status === 'overdue' || job.issueFlag ? 'has-risk' : ''}`} key={job.id} onClick={() => onOpenJob(job.id)}>
                  <div className="timeline-time"><strong>{fmtTime(job.scheduledStart)}</strong><span>{fmtTime(job.scheduledEnd)}</span></div>
                  <div className="timeline-dot"><span /></div>
                  <div className="timeline-main"><strong>{job.summary}</strong><span>{client?.name} · {tech?.name ?? 'Unassigned'}</span></div>
                  <StatusBadge value={job.status} />
                  <MoreHorizontal size={16} className="row-more" />
                </button>
              );
            })}
          </div>
        </Panel>

        <Panel eyebrow="Cash conversion" title="Revenue-to-cash funnel" description="Where completed work is becoming delayed cash." className="funnel-panel">
          <div className="funnel">
            {funnel.map((step, index) => {
              const previous = index ? funnel[index - 1].value : step.value;
              const drop = Math.max(0, previous - step.value);
              return (
                <button key={step.label} className="funnel-step" onClick={() => index === 1 && firstPending ? onOpenInvoice(firstPending.id) : undefined}>
                  <div className="funnel-label"><span>{step.label}</span><strong>{formatShortMoney(step.value)}</strong></div>
                  <div className="funnel-track"><span style={{ width: `${Math.max(9, (step.value / maxFunnel) * 100)}%` }} /></div>
                  <div className="funnel-helper"><span>{step.helper}</span>{index > 0 && drop > 0 && <em>{formatShortMoney(drop)} gap</em>}</div>
                </button>
              );
            })}
          </div>
          <div className="funnel-callout"><CircleDollarSign size={18} /><div><strong>{formatMoney(Math.max(0, completedValue - sentValue))} completed but not yet sent</strong><span>This is the fastest cash-flow leak to act on today.</span></div><ArrowRight size={16} /></div>
        </Panel>

        <div className="trend-grid">
          <Panel eyebrow="14-day trend" title="Jobs completed vs scheduled" description="Is delivery keeping pace with demand?">
            <ReactECharts option={jobsOption} style={{ height: 220 }} notMerge lazyUpdate />
          </Panel>
          <Panel eyebrow="14-day trend" title="Invoice cycle time" description="How quickly completed work reaches accounting?">
            <ReactECharts option={invoiceOption} style={{ height: 220 }} notMerge lazyUpdate />
          </Panel>
        </div>
      </div>
    </>
  );
}

function ActionRow({ icon, tone, title, body, button, onClick, disabled = false }: { icon: React.ReactNode; tone: 'danger' | 'warning' | 'neutral'; title: string; body: string; button: string; onClick: () => void; disabled?: boolean }) {
  return (
    <div className="action-row">
      <div className={`action-icon ${tone}`}>{icon}</div>
      <div className="action-copy"><strong>{title}</strong><span>{body}</span></div>
      <button className="action-button" onClick={onClick} disabled={disabled}>{button}<ArrowRight size={14} /></button>
    </div>
  );
}
