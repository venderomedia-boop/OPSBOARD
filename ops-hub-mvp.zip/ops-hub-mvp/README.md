# Ops Hub MVP

A sales-demo MVP for an executive field-service control layer.

**Demo company:** Northstar Home Services  
**Positioning:** One clear view of today's field operations without replacing dispatch, accounting or customer-feedback tools.

## What is implemented

- Executive overview with 8 live-calculated KPI cards
- Scenario switcher:
  - Normal day
  - Cash-flow risk
  - Service-quality issue
  - Understaffed day
  - Growth view
- Cross-filtering by period, technician, client and service type
- Clickable KPI drill-downs
- Operations timeline with exceptions
- Revenue-to-cash funnel
- Action center with simulated operational actions
- Interactive ECharts trend charts
- Jobs register
- Dispatch/capacity view
- Invoice queue and aging states
- Customer feedback queue
- Technician performance scorecard
- Client revenue/risk view
- Service-type metrics
- Executive report view
- Data-source / read-only architecture view
- CSV export for active filtered data
- Dark/light mode
- Responsive desktop/tablet/mobile behavior
- Demo toasts and context-preserving side drawers

## Seeded demo data

The app creates a deterministic relational demo dataset at runtime:

- 12 technicians
- 320 clients
- 7 service types
- 24 jobs in today's schedule
- 520 historical jobs across ~6 months
- Linked invoices
- Linked customer feedback

The scenario switcher changes the underlying operational conditions rather than only swapping labels.

## Tech

- React 18
- TypeScript
- Vite
- Apache ECharts / echarts-for-react
- lucide-react
- CSS design tokens

The UI remains independent from the data source layer so a future repository adapter can replace the seeded data with Supabase, Jobber, ServiceTitan, Housecall Pro, QuickBooks or CSV imports.

## Run locally

```bash
npm install
npm run dev
```

Build:

```bash
npm run build
npm run preview
```

## Demo flow

1. Open **Overview** on **Today**.
2. Switch to **Cash-flow risk**.
3. Click **Invoices awaiting issue** or use the Action Center.
4. Open an invoice/job drawer.
5. Click **Send invoice — demo action**.
6. Watch the queue/KPI recalculate.
7. Switch to **Service-quality issue** or **Understaffed day**.
8. Open Technician, Feedback or Dispatch views.
9. Close on the Data Sources screen to reinforce that Ops Hub sits above existing systems.

## Important MVP boundary

This is a demo environment. Actions are simulated in browser state. No third-party system is connected or modified.
