import { CheckCircle2, CircleDollarSign, Clock3, FileText, MapPin, MessageSquareText, Send, UserRound, Wrench, X } from 'lucide-react';
import type { KpiMetric, OpsData } from '../types';
import { formatMoney } from '../data/metrics';
import StatusBadge from './StatusBadge';

export type DrawerTarget =
  | { type: 'job'; id: string }
  | { type: 'invoice'; id: string }
  | { type: 'feedback'; id: string }
  | { type: 'technician'; id: string }
  | { type: 'client'; id: string }
  | { type: 'kpi'; metric: KpiMetric }
  | null;

const fmt = (iso?: string) => iso ? new Date(iso).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—';

export default function DetailDrawer({ target, data, onClose, onSendInvoice, onOpenJob }: { target: DrawerTarget; data: OpsData; onClose: () => void; onSendInvoice: (invoiceId: string) => void; onOpenJob: (jobId: string) => void }) {
  if (!target) return null;
  return <div className="drawer-backdrop" onMouseDown={onClose}><aside className="drawer" onMouseDown={(event)=>event.stopPropagation()}><button className="drawer-close" onClick={onClose}><X size={18}/></button>{renderContent(target, data, onSendInvoice, onOpenJob)}</aside></div>;
}

function renderContent(target: NonNullable<DrawerTarget>, data: OpsData, onSendInvoice: (id: string)=>void, onOpenJob: (id:string)=>void) {
  if (target.type === 'job') {
    const job=data.jobs.find(j=>j.id===target.id); if(!job) return <Empty/>;
    const client=data.clients.find(c=>c.id===job.clientId); const tech=data.technicians.find(t=>t.id===job.technicianId); const service=data.serviceTypes.find(s=>s.id===job.serviceTypeId); const invoice=data.invoices.find(i=>i.jobId===job.id); const feedback=data.feedback.find(f=>f.jobId===job.id);
    return <>
      <DrawerHead eyebrow="Job context" title={job.id} subtitle={job.summary} badge={<StatusBadge value={job.status}/>} />
      {job.issueFlag && <div className="drawer-alert"><Clock3 size={17}/><div><b>Operational exception</b><span>{job.issueFlag.replace('_',' ')} is attached to this job and should be reviewed.</span></div></div>}
      <div className="drawer-section"><h3>Linked context</h3><div className="detail-grid"><Detail icon={<UserRound/>} label="Client" value={client?.name}/><Detail icon={<Wrench/>} label="Service" value={service?.name}/><Detail icon={<UserRound/>} label="Technician" value={tech?.name ?? 'Unassigned'}/><Detail icon={<MapPin/>} label="Location" value={client?.location}/></div></div>
      <div className="drawer-section"><h3>Operational timing</h3><div className="event-list"><Event label="Scheduled start" value={fmt(job.scheduledStart)}/><Event label="Actual arrival" value={fmt(job.actualArrival)}/><Event label="Completed" value={fmt(job.completedAt)}/></div></div>
      <div className="drawer-section"><h3>Commercial</h3><div className="drawer-money"><div><span>Job value</span><strong>{formatMoney(job.finalAmount??job.quotedAmount)}</strong></div><div><span>Invoice status</span>{invoice?<StatusBadge value={invoice.status}/>:<StatusBadge value="not created"/>}</div></div>{invoice&&<button className="drawer-link" onClick={()=>onSendInvoice(invoice.id)}><Send size={15}/>Simulate send invoice</button>}</div>
      {feedback && <div className="drawer-section"><h3>Customer feedback</h3><div className="feedback-quote"><span>{'★'.repeat(feedback.rating)}{'☆'.repeat(5-feedback.rating)}</span><p>{feedback.comment}</p><small>{feedback.category}</small></div></div>}
      <div className="drawer-source">Sources: <b>Dispatch</b>{invoice&&<> · <b>Accounting</b></>}{feedback&&<> · <b>Customer Feedback</b></>}</div>
    </>;
  }
  if(target.type==='invoice'){
    const inv=data.invoices.find(i=>i.id===target.id); if(!inv) return <Empty/>; const job=data.jobs.find(j=>j.id===inv.jobId)!; const client=data.clients.find(c=>c.id===job.clientId);
    return <><DrawerHead eyebrow="Invoice context" title={inv.id} subtitle={`${client?.name} · ${job.id}`} badge={<StatusBadge value={inv.status}/>}/><div className="invoice-hero"><CircleDollarSign size={20}/><span>Invoice value</span><strong>{formatMoney(inv.amount)}</strong></div><div className="drawer-section"><h3>Cash journey</h3><div className="event-list"><Event label="Job completed" value={fmt(job.completedAt)}/><Event label="Invoice created" value={fmt(inv.createdAt)}/><Event label="Invoice sent" value={fmt(inv.sentAt)}/><Event label="Due date" value={fmt(inv.dueAt)}/><Event label="Paid" value={fmt(inv.paidAt)}/></div></div><div className="drawer-actions"><button className="primary-action" onClick={()=>onSendInvoice(inv.id)}><Send size={15}/>Send invoice <small>demo action</small></button><button className="secondary-action" onClick={()=>onOpenJob(job.id)}><FileText size={15}/>Open linked job</button></div><div className="drawer-source">Source: <b>Accounting</b></div></>;
  }
  if(target.type==='feedback'){
    const fb=data.feedback.find(f=>f.id===target.id); if(!fb) return <Empty/>; const job=data.jobs.find(j=>j.id===fb.jobId)!; const client=data.clients.find(c=>c.id===job.clientId); const tech=data.technicians.find(t=>t.id===job.technicianId);
    return <><DrawerHead eyebrow="Customer signal" title={`${fb.rating}.0 / 5`} subtitle={client?.name??'Customer feedback'} badge={<StatusBadge value={`${fb.rating} stars`}/>} /><div className="large-feedback"><span>{'★'.repeat(fb.rating)}{'☆'.repeat(5-fb.rating)}</span><p>“{fb.comment}”</p><small>{fb.category} · {fmt(fb.submittedAt)}</small></div><div className="drawer-section"><h3>Linked operation</h3><div className="detail-grid"><Detail icon={<FileText/>} label="Job" value={job.id}/><Detail icon={<UserRound/>} label="Technician" value={tech?.name}/><Detail icon={<Clock3/>} label="Completed" value={fmt(job.completedAt)}/><Detail icon={<CircleDollarSign/>} label="Value" value={formatMoney(job.finalAmount??job.quotedAmount)}/></div></div><button className="primary-action" onClick={()=>onOpenJob(job.id)}><FileText size={15}/>Review full job context</button><div className="drawer-source">Source: <b>Customer Feedback</b></div></>;
  }
  if(target.type==='technician'){
    const tech=data.technicians.find(t=>t.id===target.id); if(!tech) return <Empty/>; const jobs=data.jobs.filter(j=>j.technicianId===tech.id); const completed=jobs.filter(j=>j.status==='completed'); const feedback=data.feedback.filter(f=>completed.some(j=>j.id===f.jobId)); const csat=feedback.length?feedback.reduce((s,f)=>s+f.rating,0)/feedback.length:0; const revenue=completed.reduce((s,j)=>s+(j.finalAmount??j.quotedAmount),0);
    return <><DrawerHead eyebrow="Technician performance" title={tech.name} subtitle={tech.skillTags.join(' · ')} badge={<StatusBadge value={tech.status}/>} /><div className="profile-hero"><span className="avatar xl">{tech.initials}</span><div><b>{completed.length}</b><small>completed jobs</small></div><div><b>{formatMoney(revenue)}</b><small>completed revenue</small></div><div><b>{csat?csat.toFixed(1):'—'}</b><small>CSAT</small></div></div><div className="drawer-section"><h3>Recent work</h3><div className="mini-records">{jobs.slice(0,7).map(j=><button key={j.id} onClick={()=>onOpenJob(j.id)}><span><b>{j.id}</b><small>{j.summary}</small></span><StatusBadge value={j.status}/></button>)}</div></div></>;
  }
  if(target.type==='client'){
    const client=data.clients.find(c=>c.id===target.id); if(!client) return <Empty/>; const jobs=data.jobs.filter(j=>j.clientId===client.id); const ids=new Set(jobs.map(j=>j.id)); const invoices=data.invoices.filter(i=>ids.has(i.jobId)); const feedback=data.feedback.filter(f=>ids.has(f.jobId)); const spend=jobs.filter(j=>j.status==='completed').reduce((s,j)=>s+(j.finalAmount??j.quotedAmount),0); const unpaid=invoices.filter(i=>['sent','overdue'].includes(i.status)).reduce((s,i)=>s+i.amount,0);
    return <><DrawerHead eyebrow="Client account" title={client.name} subtitle={`${client.segment.replace('_',' ')} · ${client.location}`} /><div className="profile-hero client"><div><b>{jobs.length}</b><small>jobs</small></div><div><b>{formatMoney(spend)}</b><small>total spend</small></div><div><b>{formatMoney(unpaid)}</b><small>unpaid</small></div><div><b>{feedback.length?(feedback.reduce((s,f)=>s+f.rating,0)/feedback.length).toFixed(1):'—'}</b><small>CSAT</small></div></div><div className="drawer-section"><h3>Recent jobs</h3><div className="mini-records">{jobs.slice(0,7).map(j=><button key={j.id} onClick={()=>onOpenJob(j.id)}><span><b>{j.id}</b><small>{j.summary}</small></span><StatusBadge value={j.status}/></button>)}</div></div></>;
  }
  const metric=target.metric;
  return <><DrawerHead eyebrow="KPI definition" title={metric.label} subtitle={metric.helper} badge={<StatusBadge value={metric.tone??'neutral'}/>} /><div className="kpi-drawer-value">{metric.value}</div><div className="drawer-section"><h3>Why this matters</h3><p className="drawer-copy">This KPI is calculated from the currently selected period and filters. The purpose is to make the number explainable before an owner acts on it.</p><div className="metric-definition"><CheckCircle2 size={17}/><div><b>Current signal</b><span>{metric.delta}</span></div></div></div><div className="drawer-source">Metric source depends on linked <b>Dispatch</b>, <b>Accounting</b> and <b>Customer Feedback</b> records.</div></>;
}

function DrawerHead({eyebrow,title,subtitle,badge}:{eyebrow:string;title:string;subtitle?:string;badge?:React.ReactNode}){return <div className="drawer-head"><div className="eyebrow">{eyebrow}</div><div className="drawer-title-row"><h2>{title}</h2>{badge}</div>{subtitle&&<p>{subtitle}</p>}</div>}
function Detail({icon,label,value}:{icon:React.ReactNode;label:string;value?:string}){return <div className="detail-item"><span className="detail-icon">{icon}</span><div><small>{label}</small><b>{value??'—'}</b></div></div>}
function Event({label,value}:{label:string;value:string}){return <div className="event-row"><span/><div><small>{label}</small><b>{value}</b></div></div>}
function Empty(){return <div className="drawer-empty"><MessageSquareText size={28}/><h2>Record unavailable</h2><p>The selected demo record could not be found.</p></div>}
