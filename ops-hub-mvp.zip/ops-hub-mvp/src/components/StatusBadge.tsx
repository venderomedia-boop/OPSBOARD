export default function StatusBadge({ value }: { value: string }) {
  const normalized = value.replaceAll('_', ' ');
  const tone = ['overdue', 'late', 'callback', 'unassigned', '2', '1'].some((token) => value.toLowerCase().includes(token))
    ? 'danger'
    : ['in_progress', 'en_route', 'draft', 'sent', '3'].some((token) => value.toLowerCase().includes(token))
      ? 'warning'
      : ['completed', 'paid', 'available', '5', '4'].some((token) => value.toLowerCase().includes(token))
        ? 'good'
        : 'neutral';
  return <span className={`status-badge ${tone}`}>{normalized}</span>;
}
