import ReactECharts from 'echarts-for-react';
import { AlertTriangle, ArrowRight, CheckCircle2, CircleDollarSign, Clock3, Database, FileSpreadsheet, RefreshCcw, Search, ShieldCheck, Star, UsersRound } from 'lucide-react';
import type { DashboardFilters, Job, OpsData, ViewId } from '../types';
import { filterJobs, formatMoney, formatShortMoney, relatedFeedback, relatedInvoices } from '../data/metrics';
import Panel from '../components/Panel';
import StatusBadge from '../components/StatusBadge';

const time = (iso?: string) => iso ? new Date(iso).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }) : '—';
const date = (iso?: string) => iso ? new Date(iso).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';
const durationHours = (job: Job) => job.actualArrival && job.completedAt ? (new Date(job.completedAt).getTime() - new Date(job.actualArrival).getTime()) / 3600000 : 0;

export default function OperationalViews({ view, data, filters, theme, onOpenJob, onOpenInvoice, onOpenFeedback, onOpenTech, onOpenClient }: {
  view: Exclude<ViewId, 'dashboard'>;
  data: OpsData;
  filters: DashboardFilters;
  theme: 'light' | 'dark';
  onOpenJob: (id: string) => void;
  onOpenInvoice: (id: string) => void;
  onOpenFeedback: (id: string) => void;
  onOpenTech: (id: string) => void;
  onOpenClient: (id: string) => void;
}) {
  if (view === 'jobs') return <Jobs data={data} filters={filters} onOpen={onOpenJob} />;
  if (view === 'dispatch') return <Dispatch data={data} filters={filters} onOpenJob={onOpenJob} onOpenTech={onOpenTech} />;
  if (view === 'invoices') return <Invoices data={data} filters={filters} onOpen={onOpenInvoice} />;
  if (view === 'feedback') return <FeedbackView data={data} filters={filters} onOpen={onOpenFeedback} />;
  if (view === 'technicians') return <Technicians data={data} filters={filters} onOpen={onOpenTech} />;
  if (view === 'clients') return <Clients data={data} filters={filters} onOpen={onOpenClient} />;
  if (view === 'service-types') return <Services data={data} filters={filters} theme={theme} />;
  if (view === 'reports') return <Reports data={data} filters={filters} theme={theme} />;
  return <DataSources />;
}

function PageIntro({ eyebrow, title, copy, right }: { eyebrow: string; title: string; copy: string; right?: React.ReactNode }) {
  return <section className="page-intro"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{copy}</p></div>{right}</section>;
}

function SearchBar({ placeholder = 'Search current view' }: { placeholder?: string }) {
  return <div className="table-search"><Search size={15} /><input placeholder={placeholder} /></div>;
}

function Jobs({ data, filters, onOpen }: { data: OpsData; filters: DashboardFilters; onOpen: (id: string) => void }) {
  const jobs = filterJobs(data, filters).sort((a, b) => new Date(b.scheduledStart).getTime() - new Date(a.scheduledStart).getTime());
  return <>
    <PageIntro eyebrow="Execution" title="Jobs" copy="One operational queue across scheduled, active, completed and exception work." right={<div className="mini-stat"><strong>{jobs.length}</strong><span>jobs in range</span></div>} />
    <Panel title="Operational job register" description="Click any row to keep context open in the side drawer." action={<SearchBar placeholder="Search jobs, clients, technicians" />}>
      <div className="table-wrap"><table><thead><tr><th>Job</th><th>Client</th><th>Service</th><th>Technician</th><th>Window</th><th>Status</th><th>Value</th><th>Exception</th></tr></thead><tbody>
        {jobs.slice(0, 80).map((job) => { const client = data.clients.find(c => c.id === job.clientId); const tech = data.technicians.find(t => t.id === job.technicianId); const service = data.serviceTypes.find(s => s.id === job.serviceTypeId); return <tr key={job.id} onClick={() => onOpen(job.id)}><td><b>{job.id}</b><small>{job.summary}</small></td><td>{client?.name}</td><td>{service?.name}</td><td>{tech?.name ?? 'Unassigned'}</td><td>{time(job.scheduledStart)}–{time(job.scheduledEnd)}</td><td><StatusBadge value={job.status} /></td><td>{formatMoney(job.finalAmount ?? job.quotedAmount)}</td><td>{job.issueFlag ? <StatusBadge value={job.issueFlag} /> : <span className="muted">—</span>}</td></tr>; })}
      </tbody></table></div>
    </Panel>
  </>;
}

function Dispatch({ data, filters, onOpenJob, onOpenTech }: { data: OpsData; filters: DashboardFilters; onOpenJob: (id: string) => void; onOpenTech: (id: string) => void }) {
  const jobs = filterJobs(data, filters);
  const active = jobs.filter(j => ['scheduled','en_route','in_progress','overdue'].includes(j.status));
  return <>
    <PageIntro eyebrow="Capacity" title="Dispatch visibility" copy="See workload, gaps and late risk without turning this layer into a replacement dispatch board." />
    <div className="dispatch-tech-grid">
      {data.technicians.map((tech) => { const techJobs = active.filter(j => j.technicianId === tech.id); const booked = techJobs.reduce((sum, j) => sum + (new Date(j.scheduledEnd).getTime()-new Date(j.scheduledStart).getTime())/3600000, 0); const util = Math.min(100, Math.round(booked/tech.shiftHours*100)); return <button className="tech-capacity-card" key={tech.id} onClick={() => onOpenTech(tech.id)}><div className="tech-cap-head"><span className="avatar">{tech.initials}</span><div><strong>{tech.name}</strong><small>{tech.skillTags.join(' · ')}</small></div><StatusBadge value={tech.status} /></div><div className="capacity-bar"><span style={{width:`${util}%`}} /></div><div className="tech-cap-foot"><span>{techJobs.length} active jobs</span><b>{util}% utilized</b></div></button>; })}
    </div>
    <Panel title="Dispatch exceptions" description="Late, overdue and unassigned jobs that need an office decision." action={<span className="source-chip">Dispatch</span>}>
      <div className="table-wrap"><table><thead><tr><th>Job</th><th>Scheduled</th><th>Client</th><th>Technician</th><th>Status</th><th>Issue</th><th>Value</th></tr></thead><tbody>
        {active.filter(j => j.status === 'overdue' || j.issueFlag).map(job => { const client=data.clients.find(c=>c.id===job.clientId); const tech=data.technicians.find(t=>t.id===job.technicianId); return <tr key={job.id} onClick={()=>onOpenJob(job.id)}><td><b>{job.id}</b><small>{job.summary}</small></td><td>{time(job.scheduledStart)}</td><td>{client?.name}</td><td>{tech?.name ?? 'Unassigned'}</td><td><StatusBadge value={job.status}/></td><td><StatusBadge value={job.issueFlag ?? 'review'}/></td><td>{formatMoney(job.quotedAmount)}</td></tr> })}
      </tbody></table></div>
    </Panel>
  </>;
}

function Invoices({ data, filters, onOpen }: { data: OpsData; filters: DashboardFilters; onOpen: (id: string) => void }) {
  const jobs = filterJobs(data, filters); const invoices = relatedInvoices(data, jobs);
  const buckets = ['not_created','draft','sent','overdue','paid'] as const;
  return <>
    <PageIntro eyebrow="Cash" title="Invoices & collection" copy="Expose the handoff between completed work, invoice issue and cash collection." />
    <div className="summary-strip">{buckets.map(status => { const rows=invoices.filter(i=>i.status===status); return <div className="summary-cell" key={status}><span>{status.replaceAll('_',' ')}</span><strong>{formatShortMoney(rows.reduce((s,i)=>s+i.amount,0))}</strong><small>{rows.length} invoices</small></div> })}</div>
    <Panel title="Invoice queue" description="Completed work appears here before it becomes a customer invoice." action={<SearchBar placeholder="Search invoice or job" />}>
      <div className="table-wrap"><table><thead><tr><th>Invoice</th><th>Job</th><th>Client</th><th>Completed</th><th>Status</th><th>Amount</th><th>Due</th><th>Closeout lag</th></tr></thead><tbody>
        {invoices.sort((a,b)=>b.amount-a.amount).slice(0,100).map(invoice => { const job=data.jobs.find(j=>j.id===invoice.jobId)!; const client=data.clients.find(c=>c.id===job.clientId); const lag=invoice.createdAt&&job.completedAt ? (new Date(invoice.createdAt).getTime()-new Date(job.completedAt).getTime())/86400000 : null; return <tr key={invoice.id} onClick={()=>onOpen(invoice.id)}><td><b>{invoice.id}</b><small>{invoice.source}</small></td><td>{invoice.jobId}</td><td>{client?.name}</td><td>{date(job.completedAt)}</td><td><StatusBadge value={invoice.status}/></td><td><b>{formatMoney(invoice.amount)}</b></td><td>{date(invoice.dueAt)}</td><td>{lag===null ? <StatusBadge value="not created"/> : `${lag.toFixed(1)}d`}</td></tr> })}
      </tbody></table></div>
    </Panel>
  </>;
}

function FeedbackView({ data, filters, onOpen }: { data: OpsData; filters: DashboardFilters; onOpen: (id: string) => void }) {
  const jobs=filterJobs(data,filters); const feedback=relatedFeedback(data,jobs).sort((a,b)=>a.rating-b.rating); const avg=feedback.length?feedback.reduce((s,f)=>s+f.rating,0)/feedback.length:0; const negatives=feedback.filter(f=>f.rating<=3);
  const categories=['quality','communication','punctuality','pricing'];
  return <>
    <PageIntro eyebrow="Customer trust" title="Customer feedback" copy="Catch service-quality signals before they become repeat complaints or lost accounts." right={<div className="rating-hero"><Star size={18} fill="currentColor"/><strong>{avg.toFixed(1)}</strong><span>from {feedback.length} responses</span></div>} />
    <div className="feedback-summary">{categories.map(category=>{const rows=feedback.filter(f=>f.category===category);const score=rows.length?rows.reduce((s,f)=>s+f.rating,0)/rows.length:0;return <div key={category}><span>{category}</span><strong>{score?score.toFixed(1):'—'}</strong><small>{rows.length} responses</small></div>})}</div>
    <Panel title="Negative feedback queue" description={`${negatives.length} responses at 3★ or below need review.`} action={<span className="source-chip">Customer Feedback</span>}>
      <div className="feedback-list">{negatives.slice(0,20).map(item=>{const job=data.jobs.find(j=>j.id===item.jobId)!;const client=data.clients.find(c=>c.id===job.clientId);return <button key={item.id} onClick={()=>onOpen(item.id)}><div className="stars">{'★'.repeat(item.rating)}{'☆'.repeat(5-item.rating)}</div><div><strong>{client?.name}</strong><span>{item.comment}</span><small>{item.category} · {job.id} · {date(item.submittedAt)}</small></div><ArrowRight size={15}/></button>})}</div>
    </Panel>
  </>;
}

function Technicians({ data, filters, onOpen }: { data: OpsData; filters: DashboardFilters; onOpen: (id: string) => void }) {
  const jobs=filterJobs(data,{...filters,technicianId:'all'});
  const rows=data.technicians.map(tech=>{const tj=jobs.filter(j=>j.technicianId===tech.id);const completed=tj.filter(j=>j.status==='completed');const fb=data.feedback.filter(f=>completed.some(j=>j.id===f.jobId));const ontime=completed.filter(j=>j.actualArrival&&new Date(j.actualArrival).getTime()<=new Date(j.scheduledStart).getTime()+15*60000).length/Math.max(1,completed.length)*100;const revenue=completed.reduce((s,j)=>s+(j.finalAmount??j.quotedAmount),0);const avg=completed.reduce((s,j)=>s+durationHours(j),0)/Math.max(1,completed.length);const csat=fb.length?fb.reduce((s,f)=>s+f.rating,0)/fb.length:0;return{tech,count:completed.length,ontime,revenue,avg,csat,callbacks:completed.filter(j=>j.issueFlag==='callback').length}}).sort((a,b)=>b.revenue-a.revenue);
  return <><PageIntro eyebrow="Team performance" title="Technicians" copy="Coach workload and outcomes using operational context, not surveillance." />
    <Panel title="Technician scorecard" description="Period metrics respond to the date and service filters above." action={<SearchBar placeholder="Search technician" />}>
      <div className="table-wrap"><table><thead><tr><th>Technician</th><th>Jobs completed</th><th>On-time arrival</th><th>Revenue</th><th>Avg duration</th><th>CSAT</th><th>Callbacks</th></tr></thead><tbody>{rows.map(r=><tr key={r.tech.id} onClick={()=>onOpen(r.tech.id)}><td><div className="person-cell"><span className="avatar small">{r.tech.initials}</span><div><b>{r.tech.name}</b><small>{r.tech.skillTags.join(' · ')}</small></div></div></td><td>{r.count}</td><td>{Math.round(r.ontime)}%</td><td>{formatMoney(r.revenue)}</td><td>{r.avg.toFixed(1)}h</td><td>{r.csat?r.csat.toFixed(1):'—'}</td><td>{r.callbacks}</td></tr>)}</tbody></table></div>
    </Panel></>;
}

function Clients({ data, filters, onOpen }: { data: OpsData; filters: DashboardFilters; onOpen: (id: string) => void }) {
  const jobs=filterJobs(data,{...filters,clientId:'all'}); const rows=data.clients.map(client=>{const cj=jobs.filter(j=>j.clientId===client.id&&j.status==='completed');const ids=new Set(cj.map(j=>j.id));const inv=data.invoices.filter(i=>ids.has(i.jobId));const fb=data.feedback.filter(f=>ids.has(f.jobId));return{client,jobs:cj.length,spend:cj.reduce((s,j)=>s+(j.finalAmount??j.quotedAmount),0),unpaid:inv.filter(i=>['sent','overdue'].includes(i.status)).reduce((s,i)=>s+i.amount,0),csat:fb.length?fb.reduce((s,f)=>s+f.rating,0)/fb.length:0,complaints:fb.filter(f=>f.rating<=3).length}}).filter(r=>r.jobs>0).sort((a,b)=>b.spend-a.spend);
  return <><PageIntro eyebrow="Revenue & account risk" title="Clients" copy="See account value, unpaid balances and service risk in the same context." />
    <Panel title="Client portfolio" description="High-value accounts with cash or satisfaction risk float to the surface." action={<SearchBar placeholder="Search client" />}><div className="table-wrap"><table><thead><tr><th>Client</th><th>Segment</th><th>Jobs</th><th>Total spend</th><th>Unpaid balance</th><th>CSAT</th><th>Complaints</th></tr></thead><tbody>{rows.slice(0,100).map(r=><tr key={r.client.id} onClick={()=>onOpen(r.client.id)}><td><b>{r.client.name}</b><small>{r.client.location}</small></td><td>{r.client.segment.replace('_',' ')}</td><td>{r.jobs}</td><td>{formatMoney(r.spend)}</td><td>{r.unpaid?formatMoney(r.unpaid):'—'}</td><td>{r.csat?r.csat.toFixed(1):'—'}</td><td>{r.complaints? <StatusBadge value={`${r.complaints} complaints`}/>:<span className="muted">0</span>}</td></tr>)}</tbody></table></div></Panel>
  </>;
}

function Services({ data, filters, theme }: { data: OpsData; filters: DashboardFilters; theme: 'light'|'dark' }) {
  const jobs=filterJobs(data,{...filters,serviceTypeId:'all'}); const rows=data.serviceTypes.map(service=>{const sj=jobs.filter(j=>j.serviceTypeId===service.id&&j.status==='completed');const ids=new Set(sj.map(j=>j.id));const inv=data.invoices.filter(i=>ids.has(i.jobId));const fb=data.feedback.filter(f=>ids.has(f.jobId));const delays=inv.filter(i=>i.createdAt).map(i=>{const j=sj.find(x=>x.id===i.jobId);return j?.completedAt?(new Date(i.createdAt!).getTime()-new Date(j.completedAt).getTime())/86400000:0});return{service,volume:sj.length,revenue:sj.reduce((s,j)=>s+(j.finalAmount??j.quotedAmount),0),avg:sj.reduce((s,j)=>s+(j.finalAmount??j.quotedAmount),0)/Math.max(1,sj.length),callback:sj.filter(j=>j.issueFlag==='callback').length/Math.max(1,sj.length)*100,delay:delays.reduce((s,x)=>s+x,0)/Math.max(1,delays.length),csat:fb.length?fb.reduce((s,f)=>s+f.rating,0)/fb.length:0}}).sort((a,b)=>b.revenue-a.revenue);
  const text=theme==='dark'?'#a9b4c7':'#697386';
  const option={tooltip:{trigger:'axis'},grid:{left:10,right:10,top:15,bottom:0,containLabel:true},xAxis:{type:'category',data:rows.map(r=>r.service.code),axisLabel:{color:text}},yAxis:{type:'value',axisLabel:{color:text,formatter:'£{value}'},splitLine:{lineStyle:{color:theme==='dark'?'#263244':'#e9edf3'}}},series:[{type:'bar',data:rows.map(r=>r.revenue),itemStyle:{color:'#5b7cfa',borderRadius:[5,5,0,0]}}]};
  return <><PageIntro eyebrow="Service mix" title="Service types" copy="Understand which work creates volume, revenue, delay and customer friction." />
    <div className="two-col"><Panel title="Revenue by service type" description="Completed job value in the selected period."><ReactECharts option={option} style={{height:270}}/></Panel><Panel title="Service-line signals" description="Exception context beyond topline revenue."><div className="service-signal-list">{rows.slice(0,5).map(r=><div key={r.service.id}><span>{r.service.name}</span><b>{r.volume} jobs</b><em>{r.delay.toFixed(1)}d invoice lag · {r.csat?r.csat.toFixed(1):'—'} CSAT</em></div>)}</div></Panel></div>
    <Panel title="Service performance register" description="Use this view to find profitable-looking work that is operationally expensive."><div className="table-wrap"><table><thead><tr><th>Service</th><th>Volume</th><th>Revenue</th><th>Avg value</th><th>Invoice lag</th><th>CSAT</th><th>Callback rate</th></tr></thead><tbody>{rows.map(r=><tr key={r.service.id}><td><b>{r.service.name}</b><small>{r.service.code}</small></td><td>{r.volume}</td><td>{formatMoney(r.revenue)}</td><td>{formatMoney(r.avg)}</td><td>{r.delay.toFixed(1)}d</td><td>{r.csat?r.csat.toFixed(1):'—'}</td><td>{r.callback.toFixed(1)}%</td></tr>)}</tbody></table></div></Panel>
  </>;
}

function Reports({ data, filters, theme }: { data: OpsData; filters: DashboardFilters; theme:'light'|'dark' }) {
  const jobs=filterJobs(data,filters); const completed=jobs.filter(j=>j.status==='completed'); const inv=relatedInvoices(data,jobs); const fb=relatedFeedback(data,jobs); const paid=inv.filter(i=>i.status==='paid').reduce((s,i)=>s+i.amount,0); const sent=inv.filter(i=>['sent','overdue','paid'].includes(i.status)).reduce((s,i)=>s+i.amount,0); const collection=sent?paid/sent*100:0; const csat=fb.length?fb.reduce((s,f)=>s+f.rating,0)/fb.length:0;
  const text=theme==='dark'?'#a9b4c7':'#697386'; const option={tooltip:{trigger:'item'},legend:{bottom:0,textStyle:{color:text}},series:[{type:'pie',radius:['58%','78%'],center:['50%','44%'],label:{show:false},data:[{name:'Collected',value:paid,itemStyle:{color:'#22c55e'}},{name:'Outstanding',value:Math.max(0,sent-paid),itemStyle:{color:'#f59e0b'}}]}]};
  return <><PageIntro eyebrow="Executive reporting" title="Operational report" copy="A concise owner view of delivery, cash conversion and customer trust." right={<button className="export-button"><FileSpreadsheet size={15}/>Export current report</button>} />
    <div className="report-cards"><div><span>Completed revenue</span><strong>{formatMoney(completed.reduce((s,j)=>s+(j.finalAmount??j.quotedAmount),0))}</strong><small>{completed.length} completed jobs</small></div><div><span>Collection rate</span><strong>{collection.toFixed(0)}%</strong><small>Paid vs sent invoice value</small></div><div><span>Customer satisfaction</span><strong>{csat?csat.toFixed(1):'—'}</strong><small>{fb.length} responses</small></div><div><span>Exceptions</span><strong>{jobs.filter(j=>j.issueFlag||j.status==='overdue').length}</strong><small>Jobs needing review</small></div></div>
    <div className="two-col"><Panel title="Cash collection" description="Paid vs outstanding sent invoice value."><ReactECharts option={option} style={{height:260}}/></Panel><Panel title="Owner briefing" description="What deserves management attention right now?"><div className="briefing-list"><div><AlertTriangle size={17}/><span><b>Cash:</b> {formatMoney(inv.filter(i=>['not_created','draft'].includes(i.status)).reduce((s,i)=>s+i.amount,0))} of completed work has not reached a sent invoice.</span></div><div><Clock3 size={17}/><span><b>Operations:</b> {jobs.filter(j=>j.status==='overdue').length} jobs are overdue in the selected period.</span></div><div><UsersRound size={17}/><span><b>Customer:</b> {fb.filter(f=>f.rating<=3).length} low-rating feedback responses require follow-up.</span></div></div></Panel></div>
  </>;
}

function DataSources() {
  const sources=[{name:'Dispatch',system:'Field service system / CSV',sync:'2 min ago',rows:'548 jobs',health:'Healthy'},{name:'Accounting',system:'Accounting package',sync:'4 min ago',rows:'538 invoices',health:'Healthy'},{name:'Customer Feedback',system:'Reviews / survey feed',sync:'11 min ago',rows:'301 responses',health:'Healthy'}];
  return <><PageIntro eyebrow="Trust & integration" title="Data sources" copy="Ops Hub reads normalized operational data. This demo does not write back to live systems." right={<div className="read-only-badge"><ShieldCheck size={16}/>Read-only layer</div>} />
    <div className="data-source-grid">{sources.map(src=><div className="source-card" key={src.name}><div className="source-icon"><Database size={19}/></div><div className="source-copy"><strong>{src.name}</strong><span>{src.system}</span></div><StatusBadge value={src.health}/><div className="source-meta"><span>Last sync <b>{src.sync}</b></span><span>Imported <b>{src.rows}</b></span></div><button><RefreshCcw size={14}/>Simulate sync</button></div>)}</div>
    <Panel title="How this MVP is wired" description="The UI is deliberately independent from provider-specific systems."><div className="architecture-flow"><div>External systems / CSV imports</div><ArrowRight/><div>Adapters & normalizers</div><ArrowRight/><div>Canonical operations model</div><ArrowRight/><div>Analytics & KPI layer</div><ArrowRight/><div>Ops Hub UI</div></div></Panel>
  </>;
}
