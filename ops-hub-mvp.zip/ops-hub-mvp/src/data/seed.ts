import type { Client, Feedback, Invoice, Job, OpsData, ServiceType, Technician } from '../types';

const serviceTypes: ServiceType[] = [
  { id: 'svc-repair', name: 'HVAC Repair', code: 'REP' },
  { id: 'svc-maint', name: 'Preventive Maintenance', code: 'PM' },
  { id: 'svc-install', name: 'System Installation', code: 'INS' },
  { id: 'svc-plumb', name: 'Plumbing', code: 'PLB' },
  { id: 'svc-elect', name: 'Electrical', code: 'ELC' },
  { id: 'svc-boiler', name: 'Boiler Service', code: 'BLR' },
  { id: 'svc-emerg', name: 'Emergency Callout', code: 'EMG' },
];

const technicians: Technician[] = [
  ['t1', 'Jordan Reed', ['HVAC', 'Heat Pump'], 'on_job', 32],
  ['t2', 'Maya Patel', ['HVAC', 'Commercial'], 'on_job', 35],
  ['t3', 'Chris Morgan', ['Plumbing', 'Boiler'], 'available', 30],
  ['t4', 'Avery Brooks', ['Electrical', 'Controls'], 'on_job', 34],
  ['t5', 'Liam Foster', ['HVAC', 'Install'], 'available', 31],
  ['t6', 'Nina Carter', ['HVAC', 'Maintenance'], 'on_job', 33],
  ['t7', 'Theo Bennett', ['Plumbing', 'Emergency'], 'available', 29],
  ['t8', 'Sofia Walsh', ['HVAC', 'Commercial'], 'on_job', 36],
  ['t9', 'Miles Hughes', ['Electrical', 'Install'], 'off_shift', 31],
  ['t10', 'Erin Cole', ['HVAC', 'Boiler'], 'available', 30],
  ['t11', 'Noah King', ['HVAC', 'Emergency'], 'on_job', 34],
  ['t12', 'Isla Price', ['Plumbing', 'Maintenance'], 'available', 29],
].map(([id, name, skillTags, status, hourlyCost]) => ({
  id: id as string,
  name: name as string,
  initials: (name as string).split(' ').map((part) => part[0]).join(''),
  skillTags: skillTags as string[],
  status: status as Technician['status'],
  hourlyCost: hourlyCost as number,
  shiftHours: 8,
}));

const clientSeedNames = [
  'Oak & Pine Properties', 'Harper Residence', 'Summit Dental', 'Riverstone Apartments', 'The Green Room Cafe',
  'Westfield Estates', 'Miller Residence', 'Bridgepoint Offices', 'Northline Storage', 'Elm Street Pharmacy',
  'Ashford Management', 'Cedar Grove School', 'Brighton Residence', 'Parkside Veterinary', 'Ironworks Fitness',
  'Willow Court', 'Fairview Retail', 'Harrison Residence', 'Redwood Kitchens', 'Stonegate Lettings',
];

function rng(seed = 71) {
  let value = seed >>> 0;
  return () => {
    value = (value * 1664525 + 1013904223) >>> 0;
    return value / 4294967296;
  };
}

const random = rng(20260816);
const pick = <T,>(items: T[]) => items[Math.floor(random() * items.length)];
const roundMoney = (n: number) => Math.round(n / 5) * 5;
const isoAt = (date: Date, hour: number, minute = 0) => {
  const d = new Date(date);
  d.setHours(hour, minute, 0, 0);
  return d.toISOString();
};
const addMinutes = (iso: string, minutes: number) => new Date(new Date(iso).getTime() + minutes * 60000).toISOString();
const addDays = (date: Date, days: number) => {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d;
};

const clients: Client[] = Array.from({ length: 320 }, (_, index) => {
  const seeded = clientSeedNames[index % clientSeedNames.length];
  const suffix = index < clientSeedNames.length ? '' : ` ${Math.floor(index / clientSeedNames.length) + 1}`;
  const segment = index % 7 === 0 ? 'commercial' : index % 11 === 0 ? 'property_manager' : 'residential';
  const locations = ['Manchester M1', 'Salford M5', 'Stockport SK1', 'Trafford M17', 'Bolton BL1', 'Altrincham WA14', 'Oldham OL1'];
  return { id: `c${index + 1}`, name: `${seeded}${suffix}`, segment, location: locations[index % locations.length] };
});

const jobSummaries = [
  'No cooling — upstairs zone', 'Annual maintenance visit', 'Boiler pressure fault', 'Leak under kitchen sink',
  'Thermostat communication fault', 'Heat pump performance check', 'Commercial rooftop unit service',
  'No hot water', 'Condensate drain blockage', 'Electrical isolation fault', 'System replacement survey',
  'Emergency heating failure', 'Radiator balancing', 'AC compressor diagnosis', 'Filter and coil clean',
];

function createTodayJobs(today: Date): Job[] {
  const statuses: Job['status'][] = [
    ...Array(18).fill('completed'),
    'in_progress', 'in_progress', 'en_route', 'overdue', 'overdue', 'scheduled',
  ];
  const amounts = [210, 180, 260, 320, 195, 285, 410, 230, 175, 245, 290, 365, 205, 275, 330, 225, 250, 245, 310, 285, 225, 380, 460, 190];
  return statuses.map((status, index) => {
    const startHour = 7 + Math.floor(index / 3);
    const startMin = (index % 3) * 20;
    const scheduledStart = isoAt(today, startHour, startMin);
    const scheduledEnd = addMinutes(scheduledStart, 90);
    const late = status === 'overdue' || index === 3 || index === 11;
    const actualArrival = status === 'scheduled' ? undefined : addMinutes(scheduledStart, late ? 28 : Math.floor(random() * 11) - 4);
    const completedAt = status === 'completed' ? addMinutes(actualArrival ?? scheduledStart, 50 + Math.floor(random() * 45)) : undefined;
    return {
      id: `J-${String(8401 + index)}`,
      clientId: clients[index].id,
      technicianId: index === 22 ? undefined : technicians[index % 10].id,
      serviceTypeId: serviceTypes[index % serviceTypes.length].id,
      status,
      scheduledStart,
      scheduledEnd,
      actualArrival,
      completedAt,
      quotedAmount: amounts[index],
      finalAmount: status === 'completed' ? amounts[index] : undefined,
      issueFlag: status === 'overdue' ? 'late' : index === 22 ? 'unassigned' : index === 11 ? 'callback' : undefined,
      summary: jobSummaries[index % jobSummaries.length],
      source: 'Dispatch' as const,
    };
  });
}

function createHistoricalJobs(today: Date): Job[] {
  const jobs: Job[] = [];
  for (let index = 0; index < 520; index += 1) {
    const daysAgo = 1 + Math.floor(random() * 180);
    const date = addDays(today, -daysAgo);
    const startHour = 7 + Math.floor(random() * 10);
    const scheduledStart = isoAt(date, startHour, Math.floor(random() * 4) * 15);
    const duration = 45 + Math.floor(random() * 130);
    const lateMinutes = random() < 0.13 ? 18 + Math.floor(random() * 55) : Math.floor(random() * 15) - 5;
    const actualArrival = addMinutes(scheduledStart, lateMinutes);
    const completedAt = addMinutes(actualArrival, duration);
    const baseValue = roundMoney(120 + random() * 780);
    const callback = random() < 0.055;
    jobs.push({
      id: `J-${String(7880 - index)}`,
      clientId: clients[Math.floor(random() * clients.length)].id,
      technicianId: technicians[Math.floor(random() * technicians.length)].id,
      serviceTypeId: pick(serviceTypes).id,
      status: 'completed',
      scheduledStart,
      scheduledEnd: addMinutes(scheduledStart, 90),
      actualArrival,
      completedAt,
      quotedAmount: baseValue,
      finalAmount: roundMoney(baseValue * (0.94 + random() * 0.18)),
      issueFlag: callback ? 'callback' : lateMinutes > 20 ? 'late' : undefined,
      summary: pick(jobSummaries),
      source: 'Dispatch',
    });
  }
  return jobs;
}

function buildInvoices(jobs: Job[], today: Date): Invoice[] {
  const invoices: Invoice[] = [];
  for (const job of jobs) {
    if (!job.completedAt || job.status !== 'completed') continue;
    const ageDays = Math.floor((today.getTime() - new Date(job.completedAt).getTime()) / 86400000);
    const roll = random();
    let status: Invoice['status'];
    if (ageDays <= 2 && roll < 0.18) status = 'not_created';
    else if (ageDays <= 4 && roll < 0.26) status = 'draft';
    else if (ageDays > 30 && roll < 0.22) status = 'overdue';
    else if (roll < 0.74 || ageDays > 45) status = 'paid';
    else status = 'sent';

    const createdAt = status === 'not_created' ? undefined : addMinutes(job.completedAt, 30 + Math.floor(random() * 2800));
    const sentAt = ['sent', 'overdue', 'paid'].includes(status) && createdAt ? addMinutes(createdAt, 15 + Math.floor(random() * 360)) : undefined;
    const dueAt = sentAt ? addDays(new Date(sentAt), 30).toISOString() : undefined;
    const paidAt = status === 'paid' && sentAt ? addDays(new Date(sentAt), 2 + Math.floor(random() * 22)).toISOString() : undefined;
    invoices.push({
      id: `INV-${job.id.slice(2)}`,
      jobId: job.id,
      status,
      amount: job.finalAmount ?? job.quotedAmount,
      createdAt,
      sentAt,
      dueAt,
      paidAt,
      source: 'Accounting',
    });
  }

  // Make the normal scenario tell the intended sales story: several recent completed jobs await invoicing.
  const recentCandidates = invoices
    .filter((invoice) => {
      const job = jobs.find((item) => item.id === invoice.jobId);
      return job?.completedAt && new Date(job.completedAt) >= addDays(today, -4);
    })
    .slice(0, 8);
  recentCandidates.forEach((invoice, index) => {
    invoice.status = index < 5 ? 'not_created' : 'draft';
    invoice.createdAt = index < 5 ? undefined : addMinutes(jobs.find((j) => j.id === invoice.jobId)!.completedAt!, 180);
    invoice.sentAt = undefined;
    invoice.paidAt = undefined;
  });

  return invoices;
}

function buildFeedback(jobs: Job[]): Feedback[] {
  const feedback: Feedback[] = [];
  const comments = {
    punctuality: ['Engineer was polite but arrived later than expected.', 'Good work, but the arrival window slipped.'],
    quality: ['Issue returned the next morning and needed another visit.', 'Repair was completed cleanly and the system is working well.'],
    communication: ['Clear explanation and useful updates throughout.', 'I had to call twice for an update.'],
    pricing: ['Price was explained before work started.', 'The final amount was higher than I expected.'],
  } as const;
  const categories: Feedback['category'][] = ['punctuality', 'quality', 'communication', 'pricing'];
  for (const job of jobs) {
    if (!job.completedAt || random() > 0.58) continue;
    const category = pick(categories)!;
    const poor = job.issueFlag === 'callback' || (job.issueFlag === 'late' && random() < 0.55);
    const rating = poor ? (random() < 0.5 ? 2 : 3) : (random() < 0.12 ? 4 : 5);
    feedback.push({
      id: `FB-${job.id.slice(2)}`,
      jobId: job.id,
      rating: rating as Feedback['rating'],
      comment: pick([...comments[category!]]),
      submittedAt: addMinutes(job.completedAt, 180 + Math.floor(random() * 1200)),
      category,
      source: 'Customer Feedback',
    });
  }
  return feedback;
}

export function createSeedData(): OpsData {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const jobs = [...createTodayJobs(today), ...createHistoricalJobs(today)];
  const invoices = buildInvoices(jobs, today);
  const feedback = buildFeedback(jobs);
  return { technicians, clients, serviceTypes, jobs, invoices, feedback };
}
