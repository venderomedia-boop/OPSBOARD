import { ChevronDown, Download, Moon, RefreshCcw, Search, Sun } from 'lucide-react';
import type { Client, DashboardFilters, DateRange, ScenarioId, ServiceType, Technician } from '../types';
import { scenarioMeta } from '../data/scenarios';

export default function TopBar({
  filters,
  onFilters,
  scenario,
  onScenario,
  technicians,
  clients,
  serviceTypes,
  theme,
  onTheme,
  onExport,
}: {
  filters: DashboardFilters;
  onFilters: (filters: DashboardFilters) => void;
  scenario: ScenarioId;
  onScenario: (value: ScenarioId) => void;
  technicians: Technician[];
  clients: Client[];
  serviceTypes: ServiceType[];
  theme: 'light' | 'dark';
  onTheme: () => void;
  onExport: () => void;
}) {
  const update = <K extends keyof DashboardFilters>(key: K, value: DashboardFilters[K]) => onFilters({ ...filters, [key]: value });
  return (
    <header className="topbar">
      <div className="business-select">
        <div className="business-logo">N</div>
        <div><small>Business</small><strong>Northstar Home Services</strong></div>
        <ChevronDown size={15} />
      </div>

      <div className="topbar-filters">
        <label className="compact-select">
          <span>Period</span>
          <select value={filters.dateRange} onChange={(event) => update('dateRange', event.target.value as DateRange)}>
            <option value="today">Today</option>
            <option value="week">This week</option>
            <option value="month">This month</option>
          </select>
        </label>
        <label className="compact-select hide-md">
          <span>Technician</span>
          <select value={filters.technicianId} onChange={(event) => update('technicianId', event.target.value)}>
            <option value="all">All technicians</option>
            {technicians.map((tech) => <option value={tech.id} key={tech.id}>{tech.name}</option>)}
          </select>
        </label>
        <label className="compact-select hide-lg">
          <span>Service</span>
          <select value={filters.serviceTypeId} onChange={(event) => update('serviceTypeId', event.target.value)}>
            <option value="all">All services</option>
            {serviceTypes.map((service) => <option value={service.id} key={service.id}>{service.name}</option>)}
          </select>
        </label>
        <label className="compact-select hide-xl">
          <span>Client</span>
          <select value={filters.clientId} onChange={(event) => update('clientId', event.target.value)}>
            <option value="all">All clients</option>
            {clients.slice(0, 45).map((client) => <option value={client.id} key={client.id}>{client.name}</option>)}
          </select>
        </label>
      </div>

      <div className="topbar-actions">
        <div className="sync-status hide-md"><RefreshCcw size={13} /><span>Last synced <strong>2 min ago</strong></span></div>
        <label className="scenario-select">
          <select value={scenario} onChange={(event) => onScenario(event.target.value as ScenarioId)} aria-label="Demo scenario">
            {(Object.keys(scenarioMeta) as ScenarioId[]).map((key) => <option key={key} value={key}>{scenarioMeta[key].label}</option>)}
          </select>
        </label>
        <button className="icon-button hide-sm" aria-label="Search"><Search size={17} /></button>
        <button className="icon-button" onClick={onTheme} aria-label="Toggle theme">{theme === 'dark' ? <Sun size={17} /> : <Moon size={17} />}</button>
        <button className="export-button" onClick={onExport}><Download size={15} /><span>Export</span></button>
      </div>
    </header>
  );
}
