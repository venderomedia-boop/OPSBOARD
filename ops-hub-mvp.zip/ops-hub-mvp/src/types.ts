export type ScenarioId = 'normal' | 'cash' | 'quality' | 'staffing' | 'growth';
export type ViewId = 'dashboard' | 'jobs' | 'dispatch' | 'invoices' | 'feedback' | 'technicians' | 'clients' | 'service-types' | 'reports' | 'data-sources';
export type DateRange = 'today' | 'week' | 'month';

export type TechnicianStatus = 'available' | 'on_job' | 'off_shift';
export type JobStatus = 'scheduled' | 'en_route' | 'in_progress' | 'completed' | 'overdue' | 'cancelled';
export type InvoiceStatus = 'not_created' | 'draft' | 'sent' | 'overdue' | 'paid';
export type FeedbackCategory = 'punctuality' | 'quality' | 'communication' | 'pricing';

export type Technician = {
  id: string;
  name: string;
  initials: string;
  skillTags: string[];
  status: TechnicianStatus;
  hourlyCost: number;
  shiftHours: number;
};

export type Client = {
  id: string;
  name: string;
  segment: 'residential' | 'commercial' | 'property_manager';
  location: string;
};

export type ServiceType = {
  id: string;
  name: string;
  code: string;
};

export type Job = {
  id: string;
  clientId: string;
  technicianId?: string;
  serviceTypeId: string;
  status: JobStatus;
  scheduledStart: string;
  scheduledEnd: string;
  actualArrival?: string;
  completedAt?: string;
  quotedAmount: number;
  finalAmount?: number;
  issueFlag?: 'late' | 'unassigned' | 'callback' | 'missing_notes';
  summary: string;
  source: 'Dispatch';
};

export type Invoice = {
  id: string;
  jobId: string;
  status: InvoiceStatus;
  amount: number;
  createdAt?: string;
  sentAt?: string;
  paidAt?: string;
  dueAt?: string;
  source: 'Accounting';
};

export type Feedback = {
  id: string;
  jobId: string;
  rating: 1 | 2 | 3 | 4 | 5;
  comment?: string;
  submittedAt: string;
  category?: FeedbackCategory;
  source: 'Customer Feedback';
};

export type OpsData = {
  technicians: Technician[];
  clients: Client[];
  serviceTypes: ServiceType[];
  jobs: Job[];
  invoices: Invoice[];
  feedback: Feedback[];
};

export type DashboardFilters = {
  dateRange: DateRange;
  technicianId: string;
  clientId: string;
  serviceTypeId: string;
};

export type KpiMetric = {
  key: string;
  label: string;
  value: string;
  rawValue: number;
  helper: string;
  delta?: string;
  tone?: 'neutral' | 'good' | 'warning' | 'danger';
};
