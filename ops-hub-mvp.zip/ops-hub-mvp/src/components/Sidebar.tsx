import {
  Activity, BriefcaseBusiness, CalendarClock, CircleDollarSign, ClipboardCheck, FileBarChart,
  Gauge, HardHat, MessageSquareWarning, Settings2, Users, Wrench,
} from 'lucide-react';
import type { ViewId } from '../types';

const groups: { label: string; items: { id: ViewId; label: string; icon: typeof Gauge }[] }[] = [
  {
    label: 'Control',
    items: [
      { id: 'dashboard', label: 'Overview', icon: Gauge },
      { id: 'jobs', label: 'Jobs', icon: BriefcaseBusiness },
      { id: 'dispatch', label: 'Dispatch', icon: CalendarClock },
      { id: 'invoices', label: 'Invoices', icon: CircleDollarSign },
    ],
  },
  {
    label: 'Performance',
    items: [
      { id: 'feedback', label: 'Customer feedback', icon: MessageSquareWarning },
      { id: 'technicians', label: 'Technicians', icon: HardHat },
      { id: 'clients', label: 'Clients', icon: Users },
      { id: 'service-types', label: 'Service types', icon: Wrench },
      { id: 'reports', label: 'Reports', icon: FileBarChart },
    ],
  },
  { label: 'System', items: [{ id: 'data-sources', label: 'Data sources', icon: Settings2 }] },
];

export default function Sidebar({ view, onChange }: { view: ViewId; onChange: (view: ViewId) => void }) {
  return (
    <aside className="sidebar">
      <button className="brand" onClick={() => onChange('dashboard')} aria-label="Open overview">
        <span className="brand-mark"><Activity size={17} strokeWidth={2.4} /></span>
        <span>
          <strong>Ops Hub</strong>
          <small>Executive control layer</small>
        </span>
      </button>

      <div className="demo-pill"><span /> Demo environment</div>

      <nav className="nav-groups" aria-label="Main navigation">
        {groups.map((group) => (
          <div className="nav-group" key={group.label}>
            <div className="nav-label">{group.label}</div>
            {group.items.map((item) => {
              const Icon = item.icon;
              return (
                <button key={item.id} className={`nav-item ${view === item.id ? 'active' : ''}`} onClick={() => onChange(item.id)}>
                  <Icon size={17} strokeWidth={1.9} />
                  <span>{item.label}</span>
                  {item.id === 'invoices' && <span className="nav-count">7</span>}
                </button>
              );
            })}
          </div>
        ))}
      </nav>

      <div className="sidebar-trust">
        <div className="trust-icon"><ClipboardCheck size={16} /></div>
        <div><strong>Read-only demo</strong><small>No live systems are changed.</small></div>
      </div>
    </aside>
  );
}
