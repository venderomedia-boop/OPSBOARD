import type { OpsData, ScenarioId } from '../types';

export const scenarioMeta: Record<ScenarioId, { label: string; short: string; description: string }> = {
  normal: { label: 'Normal day', short: 'Normal', description: 'Healthy operation with a small set of exceptions.' },
  cash: { label: 'Cash-flow risk', short: 'Cash risk', description: 'Completed work is stacking up before invoice issue and collection.' },
  quality: { label: 'Service-quality issue', short: 'Quality risk', description: 'Feedback has softened and callbacks are increasing.' },
  staffing: { label: 'Understaffed day', short: 'Staffing', description: 'Capacity is uneven, with overloaded technicians and unassigned work.' },
  growth: { label: 'Growth view', short: 'Growth', description: 'Job volume is rising faster than admin closeout.' },
};

const clone = (data: OpsData): OpsData => ({
  technicians: data.technicians.map((item) => ({ ...item })),
  clients: data.clients,
  serviceTypes: data.serviceTypes,
  jobs: data.jobs.map((item) => ({ ...item })),
  invoices: data.invoices.map((item) => ({ ...item })),
  feedback: data.feedback.map((item) => ({ ...item })),
});

export function applyScenario(base: OpsData, scenario: ScenarioId): OpsData {
  if (scenario === 'normal') return clone(base);
  const data = clone(base);
  const now = new Date();
  const startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const recentJobIds = data.jobs
    .filter((job) => job.completedAt && new Date(job.completedAt).getTime() >= startToday - 5 * 86400000)
    .map((job) => job.id);

  if (scenario === 'cash') {
    let changed = 0;
    for (const invoice of data.invoices) {
      if (recentJobIds.includes(invoice.jobId) && changed < 12) {
        invoice.status = changed < 8 ? 'not_created' : 'draft';
        invoice.createdAt = changed < 8 ? undefined : invoice.createdAt;
        invoice.sentAt = undefined;
        invoice.paidAt = undefined;
        changed += 1;
      }
      if (changed >= 12) break;
    }
    const oldSent = data.invoices.filter((invoice) => invoice.status === 'sent').slice(0, 7);
    oldSent.forEach((invoice) => {
      invoice.status = 'overdue';
      invoice.dueAt = new Date(Date.now() - 8 * 86400000).toISOString();
    });
  }

  if (scenario === 'quality') {
    const todayCompleted = data.jobs.filter((job) => job.completedAt && new Date(job.completedAt).getTime() >= startToday).slice(0, 7);
    todayCompleted.slice(0, 4).forEach((job) => { job.issueFlag = 'callback'; });
    const lowComments = [
      'The repair did not hold and we needed another visit.',
      'We waited longer than expected and had to chase for an update.',
      'Engineer was helpful, but the issue returned later that day.',
      'Work was completed but communication around timing was poor.',
    ];
    todayCompleted.slice(0, 5).forEach((job, index) => {
      const existing = data.feedback.find((item) => item.jobId === job.id);
      if (existing) {
        existing.rating = index < 2 ? 2 : 3;
        existing.category = index % 2 === 0 ? 'quality' : 'communication';
        existing.comment = lowComments[index % lowComments.length];
      } else if (job.completedAt) {
        data.feedback.push({
          id: `FB-Q-${index}`,
          jobId: job.id,
          rating: index < 2 ? 2 : 3,
          category: index % 2 === 0 ? 'quality' : 'communication',
          comment: lowComments[index % lowComments.length],
          submittedAt: new Date(new Date(job.completedAt).getTime() + 2 * 3600000).toISOString(),
          source: 'Customer Feedback',
        });
      }
    });
  }

  if (scenario === 'staffing') {
    const todayJobs = data.jobs.filter((job) => new Date(job.scheduledStart).getTime() >= startToday && new Date(job.scheduledStart).getTime() < startToday + 86400000);
    todayJobs.slice(-5).forEach((job, index) => {
      if (index < 3) {
        job.status = 'overdue';
        job.issueFlag = index === 0 ? 'unassigned' : 'late';
      }
      if (index === 0) job.technicianId = undefined;
    });
    data.technicians.find((tech) => tech.id === 't5')!.status = 'off_shift';
    data.technicians.find((tech) => tech.id === 't10')!.status = 'off_shift';
  }

  if (scenario === 'growth') {
    // Growth is communicated via a higher recent job count and invoice lag, while keeping the base dataset deterministic.
    const recentCompleted = data.jobs.filter((job) => job.completedAt && new Date(job.completedAt).getTime() >= startToday - 21 * 86400000).slice(0, 24);
    recentCompleted.slice(0, 10).forEach((job) => {
      const invoice = data.invoices.find((item) => item.jobId === job.id);
      if (invoice) {
        invoice.status = invoice.status === 'paid' ? 'sent' : invoice.status;
        invoice.paidAt = undefined;
      }
    });
  }

  return data;
}
